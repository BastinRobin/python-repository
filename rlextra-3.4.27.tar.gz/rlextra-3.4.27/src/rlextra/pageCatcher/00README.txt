PageCatcher is ReportLab's utility for marking up, 
rearranging, re-using and filling in PDF files.

For further information, please read the file 
PageCatchIntro.html.

After installation, change directory to the
'demos' directory and execute the file
'runall.bat'.  Then look at all the PDF
files beginning with 'out'.

